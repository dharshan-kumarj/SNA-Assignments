#!/bin/bash
# =============================================
# Create Submission Zip for SNA Assignment 3
# =============================================
# This script creates a clean zip file excluding
# unnecessary files like node_modules, vendor, etc.

# Set variables
PROJECT_NAME="Assignment-3"
OUTPUT_FILE="SNA_Assignment3_DharshanKumarJ.zip"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

echo "🚀 Creating submission zip file..."
echo "=================================="

# Navigate to parent directory
cd "$(dirname "$0")/.."

# Create zip excluding unnecessary files
zip -r "$OUTPUT_FILE" "$PROJECT_NAME" \
    -x "$PROJECT_NAME/htdocs/vendor/*" \
    -x "$PROJECT_NAME/workspace/node_modules/*" \
    -x "$PROJECT_NAME/.git/*" \
    -x "$PROJECT_NAME/.git" \
    -x "$PROJECT_NAME/**/.git/*" \
    -x "$PROJECT_NAME/**/__pycache__/*" \
    -x "$PROJECT_NAME/**/.DS_Store" \
    -x "$PROJECT_NAME/**/Thumbs.db" \
    -x "$PROJECT_NAME/**/*.log" \
    -x "$PROJECT_NAME/.env" \
    -x "$PROJECT_NAME/htdocs/api/config.php" \
    -x "$PROJECT_NAME/**/package-lock.json" \
    -x "$PROJECT_NAME/**/composer.lock" \
    -x "*.zip"

echo ""
echo "✅ Successfully created: $OUTPUT_FILE"
echo "📦 File size: $(du -h "$OUTPUT_FILE" | cut -f1)"
echo ""
echo "📋 Contents:"
unzip -l "$OUTPUT_FILE" | head -30
echo "..."
echo ""
echo "🎉 Ready to submit!"
